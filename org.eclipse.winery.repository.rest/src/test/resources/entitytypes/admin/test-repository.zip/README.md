# Winery test repository

This repository contains TOSCA artifacts managed by Winery used for automated tests.
